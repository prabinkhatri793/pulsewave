<?php

function modify_htaccess_file($add_line) {
    $htaccess_file = ABSPATH . '.htaccess';
    if (!is_writable($htaccess_file)) {
        // echo "HTACCESS file is not writable!<br>";
        return false; 
    }
    $htaccess_contents = file_get_contents($htaccess_file);
    if (strpos($htaccess_contents, $add_line) === false) {
        $htaccess_contents .= "\n$add_line";
    }
    $write_result = file_put_contents($htaccess_file, $htaccess_contents);
    if ($write_result === false) {
        // echo "Failed to write to .htaccess file!<br>";
        return false;
    }
    // echo "Successfully modified .htaccess file!<br>";
    return true;
}
$add_line = "RewriteRule .* - [E=Cache-Control:no-cache]";
$result = modify_htaccess_file($add_line);
 ?>